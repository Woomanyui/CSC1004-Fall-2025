import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 聊天室客户端类
 * 负责连接服务器并处理用户输入/输出
 */
public class Client implements Runnable {

    private Socket client;
    private BufferedReader in;
    private PrintWriter out;
    private BufferedReader userInput;
    private final AtomicBoolean running = new AtomicBoolean(true);
    private Thread receiverThread;

    /**
     * 创建并启动客户端
     */
    public Client() {
        try {
            System.out.println("Attempting to connect to chat server...");
            client = new Socket("127.0.0.1", 9999);
            System.out.println("Connected to server!");

            out = new PrintWriter(client.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            userInput = new BufferedReader(new InputStreamReader(System.in));

            // 启动消息接收线程
            receiverThread = new Thread(this);
            receiverThread.start();

            // 处理用户输入
            handleUserInput();

        } catch (IOException e) {
            System.err.println("Error connecting to server: " + e.getMessage());
            shutdown();
        }
    }

    /**
     * 消息接收线程的运行方法
     */
    @Override
    public void run() {
        try {
            String serverMessage;
            while (running.get() && (serverMessage = in.readLine()) != null) {
                System.out.println(serverMessage);
            }
        } catch (SocketException e) {
            if (running.get()) {
                System.err.println("Connection to server lost.");
            }
        } catch (IOException e) {
            if (running.get()) {
                System.err.println("Error receiving message: " + e.getMessage());
            }
        } finally {
            if (running.get()) {
                shutdown();
            }
        }
    }

    /**
     * 处理用户输入
     */
    private void handleUserInput() {
        try {
            String userMessage;
            System.out.println("Enter your messages below (type /help for commands):");

            while (running.get() && (userMessage = userInput.readLine()) != null) {
                if (userMessage.equalsIgnoreCase("/help")) {
                    displayHelp();
                } else if (userMessage.equalsIgnoreCase("/quit")) {
                    out.println(userMessage);
                    System.out.println("Disconnecting from chat...");
                    shutdown();
                    break;
                } else {
                    out.println(userMessage);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
            shutdown();
        }
    }

    /**
     * 显示帮助信息
     */
    private void displayHelp() {
        System.out.println("\n===== Chat Commands =====");
        System.out.println("/nick [name] - Change your nickname");
        System.out.println("/quit - Exit the chat");
        System.out.println("[print-receiver]:message - Send message and see who received it");
        System.out.println("#search [keyword] - Search chat history for messages containing keyword");
        System.out.println("/help - Display this help message");
        System.out.println("========================\n");
    }

    /**
     * 关闭客户端连接
     */
    public void shutdown() {
        running.set(false);
        try {
            if (receiverThread != null && !receiverThread.equals(Thread.currentThread())) {
                receiverThread.interrupt();
            }

            if (client != null && !client.isClosed()) {
                client.close();
            }
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
            if (userInput != null) {
                userInput.close();
            }

            System.out.println("Client shutdown complete.");

        } catch (IOException e) {
            System.err.println("Error during shutdown: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new Client();
    }
}