import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server implements Runnable {

    private CopyOnWriteArrayList<ConnectionHandler> connections;
    private ServerSocket server;
    private boolean done;
    private ExecutorService pool;
    private List<String> chatHistory;
    private final String CHAT_HISTORY_FILE = "chat_history.txt";
    private Map<String, Set<String>> messageReceivers;

    public Server() {
        connections = new CopyOnWriteArrayList<>();
        done = false;
        chatHistory = new ArrayList<>();
        messageReceivers = new HashMap<>();

        loadChatHistory();
    }

    private void loadChatHistory() {
        try {
            File file = new File(CHAT_HISTORY_FILE);
            if (file.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line;
                while ((line = reader.readLine()) != null) {
                    chatHistory.add(line);
                }
                reader.close();
                System.out.println("Chat history loaded from file.");
            }
        } catch (IOException e) {
            System.err.println("Error loading chat history: " + e.getMessage());
        }
    }

    private void saveChatHistory() {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(CHAT_HISTORY_FILE));
            for (String message : chatHistory) {
                writer.println(message);
            }
            writer.close();
            System.out.println("Chat history saved to file.");
        } catch (IOException e) {
            System.err.println("Error saving chat history: " + e.getMessage());
        }
    }

    @Override
    public void run() {
        try {
            server = new ServerSocket(9999);
            pool = Executors.newCachedThreadPool();
            System.out.println("Chat Server started on port 9999");

            while (!done) {
                try {
                    Socket client = server.accept();
                    ConnectionHandler handler = new ConnectionHandler(client);
                    connections.add(handler);
                    pool.execute(handler);
                } catch (IOException e) {
                    if (done) {
                        break;
                    }
                    System.err.println("Error accepting client connection: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Error starting server: " + e.getMessage());
            shutdown();
        }
    }


    public void broadcast(String message, ConnectionHandler sender) {
        chatHistory.add(message);
        saveChatHistory();

        String messageId = UUID.randomUUID().toString();
        Set<String> receivers = new HashSet<>();

        for (ConnectionHandler ch : connections) {
            if (ch != null && ch.isActive()) {
                ch.sendMessage(message);

                if (ch != sender) {
                    String receiverInfo = ch.nickname + " (" + ch.userId + ")";
                    receivers.add(receiverInfo);
                }
            }
        }

        if (sender != null) {
            messageReceivers.put(sender.userId + ":" + messageId, receivers);
            sender.lastMessageId = messageId;
        }
    }


    public Set<String> getMessageReceivers(String senderId, String messageId) {
        return messageReceivers.getOrDefault(senderId + ":" + messageId, new HashSet<>());
    }


    public void shutdown() {
        try {
            done = true;
            if (pool != null) {
                pool.shutdown();
            }
            if (server != null && !server.isClosed()) {
                server.close();
            }
            saveChatHistory();

            for (ConnectionHandler ch : connections) {
                ch.shutdown();
            }
            System.out.println("Server shutdown complete");
        } catch (IOException e) {
            System.err.println("Error during shutdown: " + e.getMessage());
        }
    }


    class ConnectionHandler implements Runnable {

        private Socket client;
        private BufferedReader in;
        private PrintWriter out;
        private String nickname;
        private String userId;
        private boolean active;
        private String lastMessageId;

        public ConnectionHandler(Socket client) {
            this.client = client;
            this.userId = String.format("%05d", new Random().nextInt(100000)); // 生成5位数ID
            this.active = true;
        }

        public boolean isActive() {
            return active;
        }

        @Override
        public void run() {
            try {
                out = new PrintWriter(client.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(client.getInputStream()));

                out.println("PLEASE ENTER YOUR NAME:");
                nickname = in.readLine();
                if (nickname == null || nickname.isEmpty()) {
                    nickname = "Anonymous_" + userId;
                }

                System.out.println(nickname + " (" + userId + ") is connected");
                out.println("Welcome " + nickname + "! Your ID is: " + userId);

                if (!connections.isEmpty()) {
                    StringBuilder onlineUsers = new StringBuilder("Current online users:\n");
                    for (ConnectionHandler ch : connections) {
                        if (ch != this && ch.isActive()) {
                            onlineUsers.append("- ").append(ch.nickname).append(" (").append(ch.userId).append(")\n");
                        }
                    }
                    out.println(onlineUsers.toString());
                }

                int historyLimit = 50;
                out.println("Last " + Math.min(historyLimit, chatHistory.size()) + " messages:");
                int startIndex = Math.max(0, chatHistory.size() - historyLimit);
                for (int i = startIndex; i < chatHistory.size(); i++) {
                    out.println(chatHistory.get(i));
                }

                broadcast(timestamp() + " " + nickname + " (" + userId + ") joined the chat", this);

                String message;
                while ((message = in.readLine()) != null) {
                    if (message.startsWith("/nick ")) {
                        String[] messageSplit = message.split(" ", 2);
                        if (messageSplit.length == 2) {
                            broadcast(timestamp() + " " + nickname + " (" + userId + ") renamed to " + messageSplit[1], this);
                            nickname = messageSplit[1];
                            out.println("Successfully renamed to " + nickname);
                        } else {
                            out.println("Invalid nickname command. Usage: /nick new_nickname");
                        }
                    } else if (message.startsWith("/quit")) {
                        broadcast(timestamp() + " " + nickname + " (" + userId + ") left the chat", this);
                        shutdown();
                        break;
                    } else if (message.startsWith("[print-receiver]:")) {
                        String originalMessage = message.substring("[print-receiver]:".length());
                        if (lastMessageId != null) {
                            Set<String> receivers = getMessageReceivers(userId, lastMessageId);
                            if (receivers.isEmpty()) {
                                out.println("Your message was not received by anyone.");
                            } else {
                                out.println("Your message was received by " + receivers.size() + " users:");
                                for (String receiver : receivers) {
                                    out.println("- " + receiver);
                                }
                            }
                        } else {
                            out.println("No previous message found.");
                        }
                        broadcast(timestamp() + " " + nickname + " (" + userId + "): " + originalMessage, this);
                    } else if (message.startsWith("#search ")) {
                        String keyword = message.substring(8).trim();
                        out.println("Search results for '" + keyword + "':");
                        int resultCount = 0;
                        for (String msg : chatHistory) {
                            if (msg.toLowerCase().contains(keyword.toLowerCase())) {
                                out.println(msg);
                                resultCount++;
                            }
                        }
                        out.println("Found " + resultCount + " matching messages.");
                    } else {
                        broadcast(timestamp() + " " + nickname + " (" + userId + "): " + message, this);
                    }
                }
            } catch (IOException e) {
                System.err.println("Error handling client " + userId + ": " + e.getMessage());
            } finally {
                shutdown();
            }
        }

        public void sendMessage(String message) {
            try {
                if (out != null && active) {
                    out.println(message);
                }
            } catch (Exception e) {
                System.err.println("Error sending message to " + userId + ": " + e.getMessage());
                shutdown();
            }
        }

        public void shutdown() {
            try {
                active = false;
                if (in != null) in.close();
                if (out != null) out.close();
                if (client != null && !client.isClosed()) {
                    client.close();
                }
                connections.remove(this);
            } catch (IOException e) {
                System.err.println("Error closing connection for " + userId + ": " + e.getMessage());
            }
        }
    }

    private String timestamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    }

    public static void main(String[] args) {
        Server server = new Server();
        Thread serverThread = new Thread(server);
        serverThread.start();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Shutting down server...");
            server.shutdown();
        }));

        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Server is running. Type 'exit' to stop.");
            while (true) {
                String command = scanner.nextLine();
                if (command.equalsIgnoreCase("exit")) {
                    server.shutdown();
                    System.exit(0);
                }
            }
        }
    }
}