import tkinter as tk
import random, time

class SnakeGame:
    def __init__(self, master):
        self.master = master
        self.master.title("SnakeGame")
        self.master.resizable(False, False)
        self.master.bind("<KeyPress>", self.key_press)

        self.WIDTH, self.HEIGHT, self.GRID = 600, 400, 20
        self.SPEED = 150
        self.snake = [(100, 100), (80, 100), (60, 100)]
        self.MAX_LENGTH = 8  # 蛇的最大长度为8
        self.direction = "Right"
        self.food = None
        self.food_type = "normal"
        self.score = 0
        self.game_over = False
        self.start_time = 0
        self.obstacles = []

        self.canvas = tk.Canvas(master, width=self.WIDTH, height=self.HEIGHT, bg="black")
        self.canvas.pack()

        self.score_var = tk.StringVar()
        tk.Label(master, textvariable=self.score_var, font=("Times New Roman", 12)).pack()
        self.show_menu()

    def show_menu(self):
        self.menu_frame = tk.Frame(self.master)
        self.menu_frame.pack(pady=50)
        tk.Label(self.menu_frame, text="SnakeGame", font=("Times New Roman", 24, "bold")).pack(pady=20)
        tk.Button(self.menu_frame, text="START", font=("Times New Roman", 16),
                  command=self.start_game, width=12, height=2).pack(pady=10)
        tk.Button(self.menu_frame, text="EXIT", font=("Times New Roman", 16),
                  command=self.master.destroy, width=12, height=2).pack(pady=10)

    def start_game(self):
        self.menu_frame.destroy()
        self.snake = [(100, 100), (80, 100), (60, 100)]
        self.direction = "Right"
        self.score = 0
        self.score_var.set("SCORE: 0")
        self.game_over = False
        self.start_time = time.time()
        self.obstacles = self.create_obstacles(5)
        self.food = self.create_food()
        self.food_type = random.choice(["normal", "bonus"])
        self.update()

    def create_obstacles(self, num):
        obs = []
        while len(obs) < num:
            x = random.randint(0, (self.WIDTH - self.GRID) // self.GRID) * self.GRID
            y = random.randint(0, (self.HEIGHT - self.GRID) // self.GRID) * self.GRID
            if (x, y) not in self.snake and (x, y) != self.food:
                obs.append((x, y))
        return obs

    def create_food(self):
        while True:
            x = random.randint(0, (self.WIDTH - self.GRID) // self.GRID) * self.GRID
            y = random.randint(0, (self.HEIGHT - self.GRID) // self.GRID) * self.GRID
            if (x, y) not in self.snake and (x, y) not in self.obstacles:
                return (x, y)

    def key_press(self, event):
        key = event.keysym
        opposites = {"Up": "Down", "Down": "Up", "Left": "Right", "Right": "Left"}
        if key in opposites and self.direction != opposites[key]:
            self.direction = key

    def move_snake(self):
        head_x, head_y = self.snake[0]
        move = {"Up": (0, -self.GRID), "Down": (0, self.GRID),
                "Left": (-self.GRID, 0), "Right": (self.GRID, 0)}
        dx, dy = move[self.direction]
        new_head = (head_x + dx, head_y + dy)

        if (not 0 <= new_head[0] < self.WIDTH or
            not 0 <= new_head[1] < self.HEIGHT or
            new_head in self.snake or
            new_head in self.obstacles):
            self.game_over = True
            return

        self.snake.insert(0, new_head)
        if new_head == self.food:
            self.score += 1
            self.score_var.set(f"SCORE: {self.score}")
            
        
            if self.food_type == "bonus":
                # 如果是奖励食物，会增加2个单位
                if len(self.snake) + 1 > self.MAX_LENGTH:  # 已经加了一个头部，再加一个就超过最大长度
                    self.game_over = True
                    return
                self.snake.append(self.snake[-1])  # 增加一个额外的节点
            
            if len(self.snake) >= self.MAX_LENGTH:
                self.game_over = True
                return
                
            self.food = self.create_food()
            self.food_type = random.choice(["normal", "bonus"])
        else:
            self.snake.pop() 

    def update(self):
        if self.game_over:
            elapsed = int(time.time() - self.start_time)
            self.canvas.create_text(self.WIDTH//2, self.HEIGHT//2,
                text=f"Game over!\nlength: {len(self.snake)}\ntime: {elapsed} second",
                fill="white", font=("Times New Roman", 20), justify="center")
            if not hasattr(self, 'restart_button'):  
                self.restart_button = tk.Button(self.master, text="PLAY AGAIN", command=self.restart_game,
                                                font=("Times New Roman", 12))
                self.restart_button.pack(pady=10)
                self.menu_button = tk.Button(self.master, text="BACK TO MENU", command=self.return_to_menu,
                                             font=("Times New Roman", 12))
                self.menu_button.pack(pady=5)
            return

        self.canvas.delete("all")

        for x, y in self.obstacles:
            self.canvas.create_rectangle(x, y, x + self.GRID, y + self.GRID, fill="gray", outline="")

        fx, fy = self.food
        color = "red" if self.food_type == "normal" else "purple"
        self.canvas.create_oval(fx, fy, fx + self.GRID, fy + self.GRID, fill=color, outline="")

        for i, (x, y) in enumerate(self.snake):
            fill = "lime green" if i == 0 else "green"
            self.canvas.create_rectangle(x, y, x + self.GRID, y + self.GRID, fill=fill, outline="")

        self.move_snake()
        
        # adjust its speed
        elapsed = time.time() - self.start_time
        delay = max(50, int(self.SPEED * max(0.5, 1 - elapsed / 120)))
        self.master.after(delay, self.update)

    def restart_game(self):
        if hasattr(self, 'restart_button'):
            self.restart_button.destroy()
            delattr(self, 'restart_button')
        if hasattr(self, 'menu_button'):
            self.menu_button.destroy()
            delattr(self, 'menu_button')
            
        self.snake = [(100, 100), (80, 100), (60, 100)]
        self.direction = "Right"
        self.score = 0
        self.score_var.set("SCORE: 0")
        self.game_over = False
        self.start_time = time.time()
        self.obstacles = self.create_obstacles(5)
        self.food = self.create_food()
        self.food_type = random.choice(["normal", "bonus"])
        self.update()

    def return_to_menu(self):
        for widget in self.master.winfo_children():
            widget.destroy()
        self.canvas = tk.Canvas(self.master, width=self.WIDTH, height=self.HEIGHT, bg="black")
        self.canvas.pack()
        self.score_var = tk.StringVar()
        self.score_var.set("SCORE: 0")
        tk.Label(self.master, textvariable=self.score_var, font=("Times New Roman", 12)).pack()
        self.show_menu()

if __name__ == "__main__":
    root = tk.Tk()
    SnakeGame(root)
    root.mainloop()