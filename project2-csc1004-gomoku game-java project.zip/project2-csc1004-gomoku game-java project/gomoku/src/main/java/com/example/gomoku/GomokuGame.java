package com.example.gomoku;

import java.io.Serializable;
import java.util.Scanner;

public class GomokuGame implements Serializable {
    private static final long serialVersionUID = 1L;

    private int[][] board;          // 0: empty, 1: player1's stone, 2: player2's stone
    private int currentPlayer;      // 1: player1, 2: player2
    private boolean gameOver;       // true: game over, false: game not over
    private int winner;             // 0: no winner, 1: player 1 wins, 2: player 2 wins
    private int boardSize;          // size of the board

    private transient Scanner scanner;  // scanner for human input in console mode

    // Statistics tracking
    private int[] playerMoves = new int[3]; // index 0 unused, 1 for player 1, 2 for player 2
    private int[] playerMaxRow = new int[3]; // max consecutive stones for each player

    public GomokuGame(int boardSize) {
        if (boardSize < 5 || boardSize > 30) {
            throw new IllegalArgumentException("Board size should be between 5 and 30.");
        }
        this.boardSize = boardSize;
        board = new int[boardSize][boardSize];
        currentPlayer = 1;
        gameOver = false;
        winner = 0;
        scanner = new Scanner(System.in);
    }

    public GomokuGame() {
        this(20); // Default to 20x20 as specified in the assignment
    }

    public boolean checkWin(int x, int y) {
        int[][][] directionLines = {
                {{0, 1}, {0, -1}},   // vertical
                {{1, 0}, {-1, 0}},   // horizontal
                {{1, 1}, {-1, -1}},  // diagonal
                {{1, -1}, {-1, 1}}   // anti-diagonal
        };

        int player = board[x][y];
        int maxCount = 1;

        for (int[][] oppositeDirs : directionLines) {
            int count = 1;
            for (int[] direction : oppositeDirs) {
                int dx = direction[0];
                int dy = direction[1];
                for (int i = 1; i < 5; i++) {
                    int newX = x + i * dx;
                    int newY = y + i * dy;
                    if (!isValidPosition(newX, newY) || board[newX][newY] != player) {
                        break;
                    }
                    count++;
                }
            }
            maxCount = Math.max(maxCount, count);
            if (count >= 5) {
                return true;
            }
        }

        // Update player's max row
        playerMaxRow[player] = Math.max(playerMaxRow[player], maxCount);

        return false;
    }

    public boolean move(int x, int y) {
        // place a piece at (x, y) for the current player, and then switch to the other player
        if (gameOver) {
            return false;
        }

        if (!isValidPosition(x, y)) {
            return false;
        }

        if (board[x][y] != 0) {
            return false;
        }

        board[x][y] = currentPlayer;
        playerMoves[currentPlayer]++;

        if (checkWin(x, y)) {
            gameOver = true;
            winner = currentPlayer;
        }

        currentPlayer = currentPlayer == 1 ? 2 : 1;      // switch player
        return true;
    }

    public void undoMove(int x, int y) {
        if (!isValidPosition(x, y)) {
            return;
        }

        if (board[x][y] == 0) {
            return;
        }

        int player = board[x][y];
        board[x][y] = 0;
        playerMoves[player]--;

        // Reset game over state if necessary
        gameOver = false;
        winner = 0;

        // Switch back to the player who made this move
        currentPlayer = player;

        // Recalculate max rows
        recalculateMaxRows();
    }

    private void recalculateMaxRows() {
        // Reset max rows
        playerMaxRow[1] = 0;
        playerMaxRow[2] = 0;

        // Check all positions
        for (int i = 0; i < boardSize; i++) {
            for (int j = 0; j < boardSize; j++) {
                if (board[i][j] != 0) {
                    // This is for checking connected stones without triggering win condition
                    checkMaxRow(i, j);
                }
            }
        }
    }

    private void checkMaxRow(int x, int y) {
        int[][][] directionLines = {
                {{0, 1}, {0, -1}},   // vertical
                {{1, 0}, {-1, 0}},   // horizontal
                {{1, 1}, {-1, -1}},  // diagonal
                {{1, -1}, {-1, 1}}   // anti-diagonal
        };

        int player = board[x][y];
        int maxCount = 1;

        for (int[][] oppositeDirs : directionLines) {
            int count = 1;
            for (int[] direction : oppositeDirs) {
                int dx = direction[0];
                int dy = direction[1];
                for (int i = 1; i < 5; i++) {
                    int newX = x + i * dx;
                    int newY = y + i * dy;
                    if (!isValidPosition(newX, newY) || board[newX][newY] != player) {
                        break;
                    }
                    count++;
                }
            }
            maxCount = Math.max(maxCount, count);
        }

        playerMaxRow[player] = Math.max(playerMaxRow[player], maxCount);
    }

    public boolean isValidPosition(int x, int y) {
        return x >= 0 && x < boardSize && y >= 0 && y < boardSize;
    }

    public void switchPlayer() {
        currentPlayer = currentPlayer == 1 ? 2 : 1;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public int getWinner() {
        return winner;
    }

    public int[][] getBoard() {
        return board;
    }

    public int getBoardSize() {
        return boardSize;
    }

    public int getCurrentPlayer() {
        return currentPlayer;
    }

    public int getPlayerMoves(int player) {
        return playerMoves[player];
    }

    public int getPlayerMaxRow(int player) {
        return playerMaxRow[player];
    }

    // Methods for console version
    public void render() {
        System.out.println();
        // print the separation line
        System.out.println("---".repeat(boardSize+1));

        // print the column number, 1-start
        StringBuilder sb = new StringBuilder();
        sb.append("   ");
        for (int i = 0; i < boardSize; i++) {
            String prefix = " ";
            String suffix = (i < 9 | i == boardSize - 1) ? " " : "";
            sb.append(prefix).append(i + 1).append(suffix);
        }
        System.out.println(sb.toString());

        for (int i = 0; i < boardSize; i++) {
            // print the row number
            int rowNum = i + 1;
            System.out.print(rowNum + (rowNum < 10 ? "  ":" "));

            for (int j = 0; j < boardSize; j++) {
                if (board[i][j] == 0) {
                    System.out.print(" + ");    // empty
                } else if (board[i][j] == 1) {
                    System.out.print(" X ");    // player1
                } else {
                    System.out.print(" O ");    // player2
                }
            }
            System.out.println();
        }

        // Print statistics
        System.out.println("\nBlack (X): Moves: " + playerMoves[1] + ", Max Row: " + playerMaxRow[1]);
        System.out.println("White (O): Moves: " + playerMoves[2] + ", Max Row: " + playerMaxRow[2]);
    }

    public int[] getHumanInput() {
        if (scanner == null) {
            scanner = new Scanner(System.in);
        }

        int[] input = new int[2];
        System.out.println();
        System.out.println("Player " + currentPlayer + "'s turn " +
                (currentPlayer == 1 ? "(X)" : "(O)"));
        System.out.println("Please input the row number and column number, separated by space:");

        input[0] = scanner.nextInt();
        input[1] = scanner.nextInt();

        return input;
    }

    public void play() {
        while (!gameOver) {
            render();
            int[] input = getHumanInput();
            boolean moveSuccess = move(input[0]-1, input[1]-1);

            if (!moveSuccess) {
                System.out.println("Invalid move! Please try again.");
            }
        }

        render();
        System.out.println("Game over! The winner is player " + winner +
                (winner == 1 ? " (X)!" : " (O)!"));

        if (scanner != null) {
            scanner.close();
        }
    }
}