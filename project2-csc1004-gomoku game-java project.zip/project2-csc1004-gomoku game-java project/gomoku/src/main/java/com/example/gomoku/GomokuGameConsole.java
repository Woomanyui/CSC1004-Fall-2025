package com.example.gomoku;

/**
 * Console version of the Gomoku game
 */
public class GomokuGameConsole {
    public static void main(String[] args) {
        System.out.println("Welcome to Gomoku Game - Console Version");
        System.out.println("Board size: 20x20");
        System.out.println("X: Player 1 (Black), O: Player 2 (White)");
        System.out.println("First player to connect 5 stones in a row (horizontally, vertically, or diagonally) wins!");
        System.out.println();

        GomokuGame game = new GomokuGame(20);  // Create a 20x20 game as required
        game.play();
    }
}