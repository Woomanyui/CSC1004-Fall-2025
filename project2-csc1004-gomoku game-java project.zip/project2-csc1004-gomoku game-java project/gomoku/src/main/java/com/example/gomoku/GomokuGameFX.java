package com.example.gomoku;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;

import java.io.*;
import java.util.Optional;
import java.util.Stack;

/**
 * JavaFX implementation of the game
 */
public class GomokuGameFX extends Application {
    private static final int BOARD_SIZE = 20;
    private static final int CELL_SIZE = 35;
    private static final int CANVAS_SIZE = CELL_SIZE * BOARD_SIZE + CELL_SIZE;

    private GomokuGame game;
    private Canvas canvas;
    private GraphicsContext gc;
    private Label statusLabel;
    private Label player1Stats;
    private Label player2Stats;
    private Label timeLabel;

    // For undo/redo functionality
    private Stack<Move> moveHistory = new Stack<>();
    private Stack<Move> redoStack = new Stack<>();

    // For time limit feature
    private int timeLimit = 30;
    private int remainingTime;
    private Timeline timer;

    private int hoverX = -1;
    private int hoverY = -1;

    @Override
    public void start(Stage primaryStage) {
        game = new GomokuGame(BOARD_SIZE);

        // Main layout
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));

        // Game canvas
        canvas = new Canvas(CANVAS_SIZE, CANVAS_SIZE);
        gc = canvas.getGraphicsContext2D();

        // Status display at the bottom
        statusLabel = new Label("Current Player: Black (X)");
        statusLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Statistics display
        player1Stats = new Label("Black: Moves: 0, Max Row: 0");
        player2Stats = new Label("White: Moves: 0, Max Row: 0");
        timeLabel = new Label("Time: " + timeLimit + "s");

        // Game control buttons
        Button newGameBtn = new Button("New Game");
        newGameBtn.setOnAction(e -> resetGame());

        Button undoBtn = new Button("Undo");
        undoBtn.setOnAction(e -> undoMove());

        Button redoBtn = new Button("Redo");
        redoBtn.setOnAction(e -> redoMove());

        Button saveBtn = new Button("Save Game");
        saveBtn.setOnAction(e -> saveGame(primaryStage));

        Button loadBtn = new Button("Load Game");
        loadBtn.setOnAction(e -> loadGame(primaryStage));

        Button exitBtn = new Button("Exit");
        exitBtn.setOnAction(e -> {
            if (confirmExit()) {
                primaryStage.close();
            }
        });

        // Control panel layout
        VBox controlPanel = new VBox(10);
        controlPanel.setPadding(new Insets(10));
        controlPanel.getChildren().addAll(
                statusLabel,
                new Separator(),
                player1Stats,
                player2Stats,
                timeLabel,
                new Separator(),
                newGameBtn,
                undoBtn,
                redoBtn,
                saveBtn,
                loadBtn,
                exitBtn
        );

        // Mouse event handlers
        canvas.addEventHandler(MouseEvent.MOUSE_MOVED, this::handleMouseMove);
        canvas.addEventHandler(MouseEvent.MOUSE_CLICKED, this::handleMouseClick);

        // Add components to root layout
        root.setCenter(canvas);
        root.setRight(controlPanel);

        // Start the timer
        startTimer();

        // Draw initial board
        drawBoard();

        // Create scene and show stage
        Scene scene = new Scene(root, CANVAS_SIZE + 200, CANVAS_SIZE);
        primaryStage.setTitle("Gomoku Game");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    private void handleMouseMove(MouseEvent event) {
        int x = (int) ((event.getX() - CELL_SIZE / 2.0) / CELL_SIZE);
        int y = (int) ((event.getY() - CELL_SIZE / 2.0) / CELL_SIZE);

        if (x != hoverX || y != hoverY) {
            hoverX = x;
            hoverY = y;
            drawBoard();
        }
    }

    private void handleMouseClick(MouseEvent event) {
        if (game.isGameOver()) {
            return;
        }

        int x = (int) ((event.getX() - CELL_SIZE / 2.0) / CELL_SIZE);
        int y = (int) ((event.getY() - CELL_SIZE / 2.0) / CELL_SIZE);

        if (game.isValidPosition(x, y)) {
            boolean moveSuccess = game.move(x, y);
            if (moveSuccess) {
                // Save move for undo
                moveHistory.push(new Move(x, y, game.getCurrentPlayer() == 1 ? 2 : 1));
                redoStack.clear();

                // Reset timer for next player
                resetTimer();

                // Update UI
                drawBoard();
                updateStatus();
                updateStats();

                if (game.isGameOver()) {
                    stopTimer();
                    showGameOverDialog();
                }
            } else {
                showAlert("Invalid Move", "This position is already occupied!");
            }
        }
    }

    private void drawBoard() {
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

        // Draw background
        gc.setFill(Color.BURLYWOOD);
        gc.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

        // Draw grid lines
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(1);

        for (int i = 0; i <= BOARD_SIZE; i++) {
            double pos = CELL_SIZE / 2.0 + i * CELL_SIZE;
            gc.strokeLine(pos, CELL_SIZE / 2.0, pos, CANVAS_SIZE - CELL_SIZE / 2.0);
            gc.strokeLine(CELL_SIZE / 2.0, pos, CANVAS_SIZE - CELL_SIZE / 2.0, pos);
        }

        // Draw hover effect
        if (hoverX >= 0 && hoverX < BOARD_SIZE && hoverY >= 0 && hoverY < BOARD_SIZE) {
            if (game.getBoard()[hoverX][hoverY] == 0 && !game.isGameOver()) {
                gc.setGlobalAlpha(0.3);
                if (game.getCurrentPlayer() == 1) {
                    gc.setFill(Color.BLACK);
                } else {
                    gc.setFill(Color.WHITE);
                }
                double x = CELL_SIZE / 2.0 + hoverX * CELL_SIZE - CELL_SIZE * 0.4;
                double y = CELL_SIZE / 2.0 + hoverY * CELL_SIZE - CELL_SIZE * 0.4;
                gc.fillOval(x, y, CELL_SIZE * 0.8, CELL_SIZE * 0.8);
                gc.setGlobalAlpha(1.0);
            }
        }

        // Draw stones
        int[][] board = game.getBoard();
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                if (board[i][j] != 0) {
                    double x = CELL_SIZE / 2.0 + i * CELL_SIZE - CELL_SIZE * 0.4;
                    double y = CELL_SIZE / 2.0 + j * CELL_SIZE - CELL_SIZE * 0.4;

                    if (board[i][j] == 1) {
                        gc.setFill(Color.BLACK);
                    } else {
                        gc.setFill(Color.WHITE);
                        gc.setStroke(Color.BLACK);
                    }

                    gc.fillOval(x, y, CELL_SIZE * 0.8, CELL_SIZE * 0.8);
                    if (board[i][j] == 2) {
                        gc.strokeOval(x, y, CELL_SIZE * 0.8, CELL_SIZE * 0.8);
                    }
                }
            }
        }
    }

    private void updateStatus() {
        if (game.isGameOver()) {
            int winner = game.getWinner();
            statusLabel.setText("Game Over! " + (winner == 1 ? "Black (X)" : "White (O)") + " Wins!");
        } else {
            statusLabel.setText("Current Player: " +
                    (game.getCurrentPlayer() == 1 ? "Black (X)" : "White (O)"));
        }
    }

    private void updateStats() {
        player1Stats.setText("Black: Moves: " + game.getPlayerMoves(1) +
                ", Max Row: " + game.getPlayerMaxRow(1));
        player2Stats.setText("White: Moves: " + game.getPlayerMoves(2) +
                ", Max Row: " + game.getPlayerMaxRow(2));
    }

    private void resetGame() {
        stopTimer();
        game = new GomokuGame(BOARD_SIZE);
        moveHistory.clear();
        redoStack.clear();
        drawBoard();
        updateStatus();
        updateStats();
        startTimer();
    }

    private void undoMove() {
        if (moveHistory.isEmpty() || game.isGameOver()) {
            return;
        }

        Move move = moveHistory.pop();
        redoStack.push(move);
        game.undoMove(move.x, move.y);

        drawBoard();
        updateStatus();
        updateStats();
        resetTimer();
    }

    private void redoMove() {
        if (redoStack.isEmpty() || game.isGameOver()) {
            return;
        }

        Move move = redoStack.pop();
        moveHistory.push(move);
        game.move(move.x, move.y);

        drawBoard();
        updateStatus();
        updateStats();
        resetTimer();
    }

    private void saveGame(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Game");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Gomoku Save Files", "*.gom"));
        File file = fileChooser.showSaveDialog(stage);

        if (file != null) {
            try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
                out.writeObject(game);
                out.writeObject(moveHistory);
                out.writeObject(redoStack);
                showAlert("Game Saved", "Game successfully saved to " + file.getName());
            } catch (IOException e) {
                showAlert("Error", "Could not save the game: " + e.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void loadGame(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Load Game");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Gomoku Save Files", "*.gom"));
        File file = fileChooser.showOpenDialog(stage);

        if (file != null) {
            try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
                game = (GomokuGame) in.readObject();
                moveHistory = (Stack<Move>) in.readObject();
                redoStack = (Stack<Move>) in.readObject();

                drawBoard();
                updateStatus();
                updateStats();
                resetTimer();

                showAlert("Game Loaded", "Game successfully loaded from " + file.getName());
            } catch (IOException | ClassNotFoundException e) {
                showAlert("Error", "Could not load the game: " + e.getMessage());
            }
        }
    }

    private void startTimer() {
        remainingTime = timeLimit;
        timeLabel.setText("Time: " + remainingTime + "s");

        timer = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            remainingTime--;
            timeLabel.setText("Time: " + remainingTime + "s");

            if (remainingTime <= 0) {
                // Time's up - switch players
                game.switchPlayer();
                updateStatus();
                resetTimer();
                showAlert("Time's Up", "Your turn has ended!");
            }
        }));

        timer.setCycleCount(Timeline.INDEFINITE);
        timer.play();
    }

    private void resetTimer() {
        if (timer != null) {
            timer.stop();
        }
        startTimer();
    }

    private void stopTimer() {
        if (timer != null) {
            timer.stop();
        }
    }

    private void showGameOverDialog() {
        String winner = game.getWinner() == 1 ? "Black (X)" : "White (O)";

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Game Over");
        alert.setHeaderText("Game Over!");
        alert.setContentText("The winner is " + winner + "!");

        ButtonType newGameBtn = new ButtonType("New Game");
        ButtonType exitBtn = new ButtonType("Exit");

        alert.getButtonTypes().setAll(newGameBtn, exitBtn);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent()) {
            if (result.get() == newGameBtn) {
                resetGame();
            } else if (result.get() == exitBtn) {
                System.exit(0);
            }
        }
    }

    private boolean confirmExit() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Game");
        alert.setHeaderText("Are you sure you want to exit?");
        alert.setContentText("Any unsaved progress will be lost.");

        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Helper class for move history
    private static class Move implements Serializable {
        private static final long serialVersionUID = 1L;
        private int x;
        private int y;
        private int player; // The player who made this move

        public Move(int x, int y, int player) {
            this.x = x;
            this.y = y;
            this.player = player;
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}